#ifndef VIEWEXPENSE_H
#define VIEWEXPENSE_H

void viewExpense();

#endif 