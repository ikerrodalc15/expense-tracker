#include <stdio.h>
#include "expenses.h"

// Structure to represent an expense
struct Expense {
    char category[50];
    double amount;
};

extern struct Expense expenses[100];
extern int expenseCount;

void saveExpenses() {
    FILE *file = fopen("expenses.txt", "w");
    if(file != NULL) {
        for(int i = 0; i < expenseCount; i++) {
            fprintf(file, "%s,%.2lf\n", expenses[i].category, expenses[i].amount);
        }
        fclose(file);
    } else {
        printf("Unable to open file for writing.\n");
    }
}