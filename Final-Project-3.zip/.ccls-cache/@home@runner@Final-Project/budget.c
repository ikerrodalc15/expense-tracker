#include <stdio.h>
#include "budget.h"

double dailyBudget = 0.0;

void inputDailyBudget() {
    do {
        printf("Enter your daily budget: ");
        if (scanf("%lf", &dailyBudget) != 1) {
            printf("Invalid input. Please enter a valid number.\n");
            while (getchar() != '\n'); // Clear input buffer
        }
    } while (dailyBudget <= 0.0);
}
