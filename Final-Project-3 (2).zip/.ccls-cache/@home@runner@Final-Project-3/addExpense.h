#ifndef ADDEXPENSE_H
#define ADDEXPENSE_H

void addExpense();

#endif