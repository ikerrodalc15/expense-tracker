#ifndef DISPLAYBUDGETSTATUS_H
#define DISPLAYBUDGETSTATUS_H

void displayBudgetStatus(double totalExpense);

#endif 
