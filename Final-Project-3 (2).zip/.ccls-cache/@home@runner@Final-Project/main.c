#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "budget.h"
#include "expenses.h"

// Structure to represent an expense
struct Expense {
    char category[50];
    double amount;
    char description[100]; // New string field
};

// Function prototypes
void addExpense();
void viewExpenses();
void viewReport();
void displayBudgetStatus(double totalExpense);

// Global variables
struct Expense expenses[100];
int expenseCount = 0;

// Function to add an expense
void addExpense() {
    struct Expense newExpense;
    printf("Enter category: ");
    scanf("%s", newExpense.category);
    printf("Enter amount: ");
    scanf("%lf", &newExpense.amount);
    printf("Enter description: ");
    scanf(" %[^\n]", newExpense.description); // Read the description including spaces
    expenses[expenseCount++] = newExpense;
    saveExpenses();
    printf("Expense added successfully!\n");
}

// Function to display all expenses
void viewExpenses() {
    printf("Expense List:\n");
    printf("%-15s %-10s %-20s\n", "Category", "Amount", "Description");
    for(int i = 0; i < expenseCount; i++) {
        printf("%-15s %-10.2lf %-20s\n", expenses[i].category, expenses[i].amount, expenses[i].description);
    }
}

// Function to display expense report
void viewReport() {
    double totalExpense = 0.0;
    printf("Expense Report:\n");
    printf("%-15s %-10s %-20s\n", "Category", "Total", "Description");
    for(int i = 0; i < expenseCount; i++) {
        totalExpense += expenses[i].amount;
        printf("%-15s %-10.2lf %-20s\n", expenses[i].category, expenses[i].amount, expenses[i].description);
    }
    printf("Total: %.2lf\n", totalExpense);
    displayBudgetStatus(totalExpense);
}

// Function to display budget status
void displayBudgetStatus(double totalExpense) {
    if (dailyBudget == 0.0) {
        printf("No daily budget set.\n");
        return;
    }

    double remainingBudget = dailyBudget - totalExpense;
    if (remainingBudget >= 0) {
        printf("You have %.2lf left on your daily budget.\n", remainingBudget);
    } else {
        printf("You have exceeded your daily budget by %.2lf.\n", -remainingBudget);
    }
}

int main() {
    int choice;
    inputDailyBudget(); // Input daily budget

    do {
        printf("\nExpense Tracker\n");
        printf("1. Add Expense\n");
        printf("2. View Expenses\n");
        printf("3. View Report\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");

        // Clear input buffer
        while (getchar() != '\n');

        // Read user choice
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            continue;
        }

        switch(choice) {
            case 1:
                addExpense();
                break;
            case 2:
                viewExpenses();
                break;
            case 3:
                viewReport();
                break;
            case 4:
                printf("Exiting program...\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while(choice != 4);

    return 0;
}
