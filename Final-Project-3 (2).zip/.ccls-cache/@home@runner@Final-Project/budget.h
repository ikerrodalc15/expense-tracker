#ifndef BUDGET_H
#define BUDGET_H

extern double dailyBudget;

void inputDailyBudget();

#endif