#ifndef EXPENSES_H
#define EXPENSES_H

void saveExpenses();

#endif